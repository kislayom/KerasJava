package com.kislay.keras.javaimport;

import org.deeplearning4j.nn.modelimport.keras.exceptions.InvalidKerasConfigurationException;
import org.deeplearning4j.nn.modelimport.keras.exceptions.UnsupportedKerasConfigurationException;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.nd4j.linalg.cpu.nativecpu.NDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.StandardScaler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;


public class ImportFromKeras {
    public static Logger logger = LoggerFactory.getLogger(ImportFromKeras.class);
    public static void main(String args[]) throws UnsupportedKerasConfigurationException, IOException, InvalidKerasConfigurationException {
       MultiLayerNetwork model = org.deeplearning4j.nn.modelimport.keras.KerasModelImport.importKerasSequentialModelAndWeights("/home/kislay/deep-learning/data/model/ann_kislay.bak");


        BufferedReader read= new BufferedReader(new FileReader("/home/kislay/deep-learning/data/test.csv"));
        String line="";
        String data[][]= new String[2000][10];
        int counter=0;
        while((line=read.readLine())!=null ){
            String cols[]=line.split(",");
            for(int i=3;i<cols.length-1;i++){
                data[counter][i-3]=cols[i];
            }
            counter++;
        }

        for(int i=0;i<20;i++)
        System.out.println(Arrays.toString(data[i]));

        for(int i=0;i<2000;i++){

            switch(data[i][1]){
                case "Germany":
                    data[i][1]="1";
                    break;
                case "France":
                    data[i][1]="0";
                    break;
                case "Spain":
                    data[i][1]="2";
                    break;
            }

            switch(data[i][2]){
                case "Male":
                    data[i][2]="1";
                    break;
                case "Female":
                    data[i][2]="0";

            }

        }

        float dataFloat[][]= new float[2000][10];
        for(int i=0;i<2000;i++){
            for(int j=0;j<10;j++){
                dataFloat[i][j]=Float.parseFloat(data[i][j]);
            }
        }

        System.out.println("Converted float Result");
        for(int i=0;i<20;i++)
            System.out.println(Arrays.toString(data[i]));

        NDArray array=new NDArray(dataFloat);
        DataSet sd= new DataSet(array,null);
        StandardScaler sc= new StandardScaler();
        sc.fit(sd);
        sc.transform(sd);

        NDArray out= (NDArray) sc.getStd();
        System.out.println(out);



        read.close();

        org.nd4j.linalg.dataset.api.DataSet set=new DataSet(null,null);

//        model.
       // System.out.println(model);

    }

}
